import os
import pandas as pd

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Image,
    PageBreak,
    Table,
    TableStyle,
    KeepTogether
)

# Paths

BASE_DIR = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

DATA_DIR = os.path.join(BASE_DIR, "data")
REPORTS_DIR = os.path.join(BASE_DIR, "reports")
CHARTS_DIR = os.path.join(REPORTS_DIR, "charts")
TABLES_DIR = os.path.join(REPORTS_DIR, "tables")

OUTPUT_PDF = os.path.join(
    REPORTS_DIR,
    "Adult_Income_EDA_Report.pdf"
)

CLEANED_FILE = os.path.join(
    DATA_DIR,
    "adult_income_cleaned.csv"
)

EDA_SUMMARY_FILE = os.path.join(
    TABLES_DIR,
    "eda_summary.csv"
)

CLEANING_LOG_FILE = os.path.join(
    TABLES_DIR,
    "cleaning_log.csv"
)

# Load cleaned dataset

df = pd.read_csv(CLEANED_FILE)

# Document setup

doc = SimpleDocTemplate(
    OUTPUT_PDF,
    pagesize=A4,
    rightMargin=40,
    leftMargin=40,
    topMargin=40,
    bottomMargin=40
)

styles = getSampleStyleSheet()

title_style = ParagraphStyle(
    "TitleStyle",
    parent=styles["Title"],
    alignment=TA_CENTER,
    fontSize=22,
    spaceAfter=20
)

heading_style = ParagraphStyle(
    "HeadingStyle",
    parent=styles["Heading1"],
    fontSize=16,
    spaceBefore=15,
    spaceAfter=10
)

body_style = ParagraphStyle(
    "BodyStyle",
    parent=styles["BodyText"],
    fontSize=10,
    leading=15,
    spaceAfter=10
)

story = []

# Title page

story.append(Spacer(1, 100))

story.append(
    Paragraph(
        "Adult Income Analysis",
        title_style
    )
)

story.append(
    Paragraph(
        "Exploratory Data Analysis",
        title_style
    )
)

story.append(Spacer(1, 30))

story.append(
    Paragraph(
        "UCI Adult Income Dataset",
        body_style
    )
)





# 1. ########Introduction

story.append(
    Paragraph(
        "1. Introduction",
        heading_style
    )
)

story.append(
    Paragraph(
        "This project analyzes the UCI Adult Income dataset to understand "
        "which demographic, education, and work characteristics are "
        "associated with an annual income above USD 50K.",
        body_style
    )
)

story.append(
    Paragraph(
        "The project includes data collection, data cleaning, feature "
        "engineering, exploratory data analysis, visualization, and "
        "interpretation of the results.",
        body_style
    )
)

# 2.###### Business Question

story.append(
    Paragraph(
        "2. Business Question",
        heading_style
    )
)

story.append(
    Paragraph(
        "Which demographic, education, and work characteristics are "
        "associated with an annual income above USD 50K in this census dataset?",
        body_style
    )
)

# 3.########## Dataset Description

story.append(
    Paragraph(
        "3. Dataset Description",
        heading_style
    )
)

story.append(
    Paragraph(
        "The dataset used in this project is the UCI Adult Income dataset. "
        "It contains 48,842 records and 14 original features. The target "
        "variable represents two income groups: <=50K and >50K.",
        body_style
    )
)

story.append(
    Paragraph(
        "The dataset contains both numerical and categorical variables, "
        "including age, education, occupation, workclass, sex, capital gain, "
        "capital loss, and hours worked per week.",
        body_style
    )
)

# 4.########## Data Collection

story.append(
    Paragraph(
        "4. Data Collection",
        heading_style
    )
)

story.append(
    Paragraph(
        "The official UCI Adult dataset was collected from two files: "
        "adult.data and adult.test. The training partition contains 32,561 "
        "records and the test partition contains 16,281 records.",
        body_style
    )
)

story.append(
    Paragraph(
        "The two partitions were combined into one dataset and the "
        "source_split column was preserved to identify the original partition.",
        body_style
    )
)

# 5. #############Data Cleaning

story.append(
    Paragraph(
        "5. Data Cleaning",
        heading_style
    )
)

cleaning_points = [
    "Leading and trailing whitespace was removed from categorical values.",
    "The UCI '?' and empty values were converted to missing values.",
    "Missing workclass, occupation, and native_country values were replaced with 'Unknown'.",
    "Expected numeric columns were converted using numeric coercion.",
    "Core numeric values were checked for invalid ranges.",
    "29 exact duplicate rows were identified and retained.",
    "Income labels were normalized by removing the trailing period.",
    "The high_income binary indicator was created."
]

for point in cleaning_points:
    story.append(
        Paragraph(
            "• " + point,
            body_style
        )
    )

# 6. ##########Feature Engineering

story.append(
    Paragraph(
        "6. Feature Engineering",
        heading_style
    )
)

feature_points = [
    "high_income: 1 for income >50K and 0 otherwise.",
    "age_group: grouped age into defined age bands.",
    "hours_group: grouped weekly working hours into defined bands.",
    "net_capital: calculated as capital_gain minus capital_loss."
]

for point in feature_points:
    story.append(
        Paragraph(
            "• " + point,
            body_style
        )
    )

# 7.########## Exploratory Data Analysis


story.append(
    Paragraph(
        "7. Exploratory Data Analysis",
        heading_style
    )
)

story.append(
    Paragraph(
        "The following analyses were performed according to the project "
        "objectives.",
        body_style
    )
)
story.append(PageBreak())
# Function to add charts

def add_chart(chart_name, title, insight):

    chart_path = os.path.join(
        CHARTS_DIR,
        chart_name
    )

    if os.path.exists(chart_path):

        chart_elements = []

        chart_elements.append(
            Paragraph(
                title,
                heading_style
            )
        )

        chart_elements.append(
            Image(
                chart_path,
                width=450,
                height=300
            )
        )

        chart_elements.append(
            Paragraph(
                "<b>Insight:</b> " + insight,
                body_style
            )
        )

   

        story.append(KeepTogether(chart_elements))


# Question 1

add_chart(
    "01_overall_income_distribution.png",
    "7.1 Overall Income Distribution",
    "The chart shows the proportion of records in each income group."
)

# Question 2

add_chart(
    "02_income_by_education.png",
    "7.2 Income >50K Rate by Education",
    "Higher education levels generally show higher >50K rates in this dataset."
)

# Question 3

add_chart(
    "03_income_by_occupation.png",
    "7.3 Income >50K Rate by Occupation",
    "Income >50K rates vary across occupation categories."
)

# Question 4

add_chart(
    "04_income_by_age_group.png",
    "7.4 Income >50K Rate by Age Group",
    "Income >50K rates vary across age groups."
)

# Question 5

add_chart(
    "05_income_by_workclass.png",
    "7.5 Income >50K Rate by Workclass",
    "Income >50K rates vary across workclass categories."
)

# Question 6

add_chart(
    "06_income_by_sex.png",
    "7.6 Income >50K Rate by Sex",
    "Income >50K rates differ between male and female groups in this dataset."
)

# Question 7

add_chart(
    "07_working_hours_by_income.png",
    "7.7 Weekly Working Hours by Income",
    "The >50K group has a higher average number of weekly working hours."
)

# Question 8

add_chart(
    "08_numeric_correlation_heatmap.png",
    "7.8 Numeric Relationships",
    "The correlation analysis shows descriptive associations among important numeric variables. Correlation does not imply causation."
)

# 8.######### EDA Summary

story.append(PageBreak())

story.append(
    Paragraph(
        "8. EDA Summary",
        heading_style
    )
)

if os.path.exists(EDA_SUMMARY_FILE):

    summary_df = pd.read_csv(EDA_SUMMARY_FILE)

    table_data = [
        ["EDA Question", "Main Finding"]
    ]

    for _, row in summary_df.iterrows():

        table_data.append([
            str(row["EDA Question"]),
            str(row["Main Finding"])
        ])

    table = Table(
        table_data,
        colWidths=[180, 300]
    )

    table.setStyle(
        TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5)
        ])
    )

    story.append(table)

# 9.############ Limitations



story.append(
    Paragraph(
        "9. Limitations",
        heading_style
    )
)

limitations = [
    "The dataset is historical and may not represent current income patterns.",
    "The analysis identifies associations and does not establish causation.",
    "Demographic variables should be interpreted carefully.",
    "The visualizations are unweighted summaries and do not account for survey/sample weights.",
    "This project focuses on descriptive analysis and does not build a predictive model."
]

for limitation in limitations:

    story.append(
        Paragraph(
            "• " + limitation,
            body_style
        )
    )

# 10. ########Conclusion

story.append(
    Paragraph(
        "10. Conclusion",
        heading_style
    )
)

story.append(
    Paragraph(
        "The exploratory analysis shows that income >50K is associated with "
        "differences across education, occupation, age group, workclass, sex, "
        "and weekly working hours in this dataset.",
        body_style
    )
)

story.append(
    Paragraph(
        "These findings are descriptive associations rather than causal "
        "relationships. The cleaned dataset and analysis provide a foundation "
        "for further statistical analysis or predictive modeling.",
        body_style
    )
)

# Create PDF

doc.build(story)

print("PDF report created successfully.")
print("Saved at:")
